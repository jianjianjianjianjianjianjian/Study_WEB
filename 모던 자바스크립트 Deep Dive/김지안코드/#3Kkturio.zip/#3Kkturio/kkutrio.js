let appendseconds = document.getElementById("seconds");
let appendmilisec = document.getElementById("milisec");
let counting = 1;
let Interval_timer;
let score = 0;

function start() {
  setPreview();
  timer();
}

function timer() {
    let sec = calcSec();
    let milisec = 99;
    Interval_timer = setInterval(() => {
      milisec--;
      if (milisec > 9) appendmilisec.textContent = milisec;
      else if (milisec <= 9 && milisec >= 0) appendmilisec.textContent = "0" + milisec;
      if (milisec < 0) {
        sec--;
        if (sec >= 0) {
          appendseconds.textContent = sec > 9 ? sec : "0" + sec;
          milisec = 99;
        }
      }
      if (sec < 0) {
        clear();
        stopTimer();
        alert(`round${counting}은(는) 실패입니다.`);
        return;
      }
    }, 10);
}

function stopTimer() {
    clearInterval(Interval_timer);
    if (counting < 3) nextRound();
    else endGame();
}

function clear() {
    appendmilisec.textContent = "00";
    appendseconds.textContent = "00";
}

function endGame() {
    alert("모든 게임을 완료하였습니다.");
    round.textContent = "게임종료";
    alert(`당신의 점수는 ${score}점 입니다.`);
    clear();
    document.getElementById("preview").value = "게임종료";
    document.getElementById("answer").value = "게임종료";
    location.reload();
}

function nextRound() {
    counting++;
    let round = document.getElementById("round");
    round.textContent = "round" + counting;
    let sec = calcSec();
    appendseconds.textContent = "0" + sec;
    milisec = 0;
    appendmilisec.textContent = "0" + milisec;
    document.getElementById("preview").value = "";
    document.getElementById("answer").value = "";
    setPreview();
}

function calcSec(){
    return 10 - counting * 2;
}

function setPreview() {
    let preview = document.getElementById("preview");
    if (counting === 1) preview.value = "1렙";
    else if (counting === 2) preview.value = "2렙";
    else if (counting === 3) preview.value = "3렙";
}

function checkEnter(event) {
    // 13 = enterkey
    if(event.keyCode !== 13) return;
    answer = document.getElementById("answer").value;
    preview = document.getElementById("preview").value;
    if (answer === preview) {
        alert(`round${counting}은(는) 성공입니다.`);
        score++;
        stopTimer();
        return;
    }
    alert("일치하지 않습니다.");
    return;
}